package com.orm.landminds;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.varunest.sparkbutton.SparkButton;
import com.varunest.sparkbutton.SparkEventListener;

import java.util.ArrayList;

public class LevelOne extends AppCompatActivity {

    private SoundFx sound;
    private Dialog myDialog;
    private TextView textView,timeView, tryView;
    private ImageButton nextButt, nextButt2;
    private Button startButton;
    private CountDownTimer PatternCD,TimerCD;
    private int Tries = 0;


    private int checkCount = 0;
    private String levels = "Level ";
    //012
    //345
    //678
    private long millisInFuture[] = {800,700,600,500,400,300,250,200,200};
    private SparkButton buttons[] = new SparkButton[9];
    private int GhostPattern[][] ={
            {0,1,2,5,4,3,6,7,8},//Level One
            {0,3,6,2,5,8,7,4,1},//Level Two
            {4,5,8,7,6,3,0,1,2,5,4},//Level Three
            {0,1,3,6,4,2,5,7,8},//Level Four
            {8,4,0,6,4,2,3,4,5,1,4,7},//Level Five
            {0,3,6,1,4,7,2,5,8,6,7,8,3,4,5,0,1,2},//Level Six
            {0,3,6,2,5,8,1,3,5,7,4},//Level Seven
            {0,1,2,5,4,3,6,7,8,7,6,3,4,5,2,1,0},//Level Eight
            {0,4,8,8,4,0,2,4,6,6,4,2,3,4,5,1,4,7}//Level Nine
    };
    private ArrayList<Integer> PlayerPattern = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_one);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        sound = new SoundFx(this);
        myDialog = new Dialog(this);

        buttons[0] = findViewById(R.id.B1);
        buttons[1] = findViewById(R.id.B2);
        buttons[2] = findViewById(R.id.B3);
        buttons[3] = findViewById(R.id.B4);
        buttons[4] = findViewById(R.id.B5);
        buttons[5] = findViewById(R.id.B6);
        buttons[6] = findViewById(R.id.B7);
        buttons[7] = findViewById(R.id.B8);
        buttons[8] = findViewById(R.id.B9);

        startButton = findViewById(R.id.start);
        textView = findViewById(R.id.textView);
        timeView = findViewById(R.id.timeID);
        tryView = findViewById(R.id.tryid);

        String s = levels + (Levels.level+1);
        textView.setText(s);
    }
    public void sparkOn(final int j){ //Enables the buttons.
            buttons[j].setEventListener(new SparkEventListener() {
                @Override
                public void onEvent(ImageView button, boolean buttonState) {
                    ButtonPositionChecker(j);
                }

                @Override
                public void onEventAnimationEnd(ImageView button, boolean buttonState) {

                }

                @Override
                public void onEventAnimationStart(ImageView button, boolean buttonState) {

                }
            });
        }
    public void sparkOff(){
        for(int j = 0; j < 9; j++){
            buttons[j].setEventListener(new SparkEventListener() {
                @Override
                public void onEvent(ImageView button, boolean buttonState) {

                }

                @Override
                public void onEventAnimationEnd(ImageView button, boolean buttonState) {

                }

                @Override
                public void onEventAnimationStart(ImageView button, boolean buttonState) {

                }
            });
        }
    }   //Disables the buttons.
    public void startPattern(View view) {       //Starts the pattern and enables the buttons.

        if (view.getId() == R.id.start) {

            Tries++;
            tryView.setText("Tries: " + Tries);
            startButton.setVisibility(view.INVISIBLE);
            Path();

        }
}   //Starts the pattern.
    public void AnimationSpeed(){
        if(Levels.level <= 5) {
            for (int i = 0; i < 9; i++) {
                buttons[i].setAnimationSpeed(1.0f);
            }
        }else{
            for (int i = 0; i < 9; i++) {
                buttons[i].setAnimationSpeed(1.1f);
            }
        }
    }
    public void Path(){  //Animation of Pattern
        Levels.count = 0;
        AnimationSpeed(); //Conditional Animation 4Speed

        PatternCD = new CountDownTimer(millisInFuture[Levels.level]*GhostPattern[Levels.level].length, millisInFuture[Levels.level]){

            @Override
            public void onTick(long millisUntilFinished ) {
                sound.playPrimedSound();
                buttons[GhostPattern[Levels.level][Levels.count]].playAnimation();
                Levels.count++;
            }
            @Override
            public void onFinish() {
                for( int i = 0; i < 9; i++){
                    sparkOn(i);                 //Enable buttons after the pattern
                }
                timer();
            }
        }.start();

    }
    public void timer(){
        Levels.time = 30;
        TimerCD = new CountDownTimer(30000,1000){
            @Override
            public void onTick(long millisUntilFinished ) {
                timeView.setText(millisUntilFinished/1000+ "");
                Levels.time--;
            }
            @Override
            public void onFinish() {

                retryPopup();
            }
        }.start();
    }
    public void buttonClicked(View view){

        switch(view.getId()) {
            case R.id.B1:
                ButtonPositionChecker(0);
                break;

            case R.id.B2:
                ButtonPositionChecker(1);
                break;

            case R.id.B3:
                ButtonPositionChecker(2);
                break;

            case R.id.B4:
                ButtonPositionChecker(3);
                break;

            case R.id.B5:
                ButtonPositionChecker(4);
                break;

            case R.id.B6:
                ButtonPositionChecker(5);
                break;

            case R.id.B7:
                ButtonPositionChecker(6);
                break;

            case R.id.B8:
                ButtonPositionChecker(7);
                break;

            case R.id.B9:
                ButtonPositionChecker(8);
                break;

        }
    }
    public void ButtonPositionChecker(int x){   //Checks the position of the button clicked.

        PlayerPattern.add(x);           //Push the position into the array.

        if(PlayerPattern.get(checkCount) == GhostPattern[Levels.level][checkCount]){    //Compares the button position to the GhostPattern's position

            if(PlayerPattern.size() == GhostPattern[Levels.level].length) {

                sound.playNextSound();
                TimerCD.cancel();

                    if(Levels.time >= 24){
                        Levels.timeProgress[Levels.level] = Levels.time;
                    }else if(Levels.time < 24 && Levels.time > 18){
                        Levels.timeProgress[Levels.level] = Levels.time;
                    }else{
                        Levels.timeProgress[Levels.level] = Levels.time;
                    }

                if(Levels.level == 8){

                        finish();
                    Intent intent = new Intent(this,ResultActivity.class);
                    startActivity(intent);

                }else{
                    nextLevelPopup();
                }

            }else {
                if(PlayerPattern.size() < 10){
                    sound.playplantSound();
//                    buttons[x].setImageResource(R.drawable.butt3);
                    checkCount++;
                }else{
                    sound.playplantSound();
//                    buttons[x].setImageResource(R.drawable.butt1);
                    checkCount++;
                }
            }
        }else{

            sparkOff();
            sound.playHitSound();
            PatternCD.cancel();

            retryPopup();
        }
    }
    public void Retry(){
        PlayerPattern = new ArrayList<>();
        checkCount = 0;
        Levels.time = 30;
        timeView.setText(Levels.time + "s");
        startButton.setVisibility(View.VISIBLE);
    }
    public void nextGame(){
        PlayerPattern = new ArrayList<>();

        Tries = 0;
        Levels.time = 30;
        timeView.setText(Levels.time + "s");
        tryView.setText("Tries: " + Tries);
        checkCount = 0;
        sparkOff();
        startButton.setVisibility(View.VISIBLE);
        Levels.level++;
        String s = levels + (Levels.level+1);
        textView.setText(s);
    }
    public void nextLevelPopup(){

        myDialog.setContentView(R.layout.popup);
        nextButt = myDialog.findViewById(R.id.nextButt);

        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();

        nextButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myDialog.dismiss();
                nextGame();
            }
        });

    }
    public void retryPopup(){
        TimerCD.cancel();

        myDialog.setContentView(R.layout.retry);
        nextButt2 = myDialog.findViewById(R.id.nextButt2);
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
        nextButt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myDialog.dismiss();
                Retry();
            }
        });
        startButton.setVisibility(View.VISIBLE);
    }
    @Override
    public void onBackPressed()
    {
        System.exit(0);

    }
}
