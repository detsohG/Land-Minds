package com.orm.landminds;

public class Levels {
    public static int level;
    public static int count;
    public static int time = 30;
    public static int timeProgress[] = new int[9];
    public static boolean notClicked = true;


}