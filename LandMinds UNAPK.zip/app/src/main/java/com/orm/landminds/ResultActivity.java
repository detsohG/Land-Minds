package com.orm.landminds;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

public class    ResultActivity extends AppCompatActivity {

    public ImageView progress[] = new ImageView[9];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        progress[0] = findViewById(R.id.P1);
        progress[1] = findViewById(R.id.P2);
        progress[2] = findViewById(R.id.P3);
        progress[3] = findViewById(R.id.P4);
        progress[4] = findViewById(R.id.P5);
        progress[5] = findViewById(R.id.P6);
        progress[6] = findViewById(R.id.P7);
        progress[7] = findViewById(R.id.P8);
        progress[8] = findViewById(R.id.P9);

        for(int i = 0; i < progress.length; i++){
            if(Levels.timeProgress[i]>= 24){
                progress[i].setImageResource(R.drawable.myrect5);
            }else if(Levels.timeProgress[i] < 24 && Levels.timeProgress[i] > 18){
                progress[i].setImageResource(R.drawable.myrect4);
            }else{
                progress[i].setImageResource(R.drawable.myrect3);
            }
        }


    }
}
