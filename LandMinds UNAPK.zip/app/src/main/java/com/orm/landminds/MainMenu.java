package com.orm.landminds;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;


public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

    }

    public void levelClicked(View view){

        Intent intent = new Intent(this, LevelOne.class);
        switch(view.getId()) {
            case R.id.lvl1:
                Levels.level = 0;
                startActivity(intent);
                break;

            case R.id.lvl2:
                Levels.level = 1;
                startActivity(intent);
                break;

            case R.id.lvl3:
                Levels.level = 2;
                startActivity(intent);
                break;

            case R.id.lvl4:
                Levels.level = 3;
                startActivity(intent);
                break;

            case R.id.lvl5:
                Levels.level = 4;
                startActivity(intent);
                break;

            case R.id.lvl6:
                Levels.level = 5;
                startActivity(intent);
                break;

            case R.id.lvl7:
                Levels.level = 6;
                startActivity(intent);
                break;

            case R.id.lvl8:
                Levels.level = 7;
                startActivity(intent);
                break;

            case R.id.lvl9:
                Levels.level = 8;
                startActivity(intent);
                break;
        }
    }

}
