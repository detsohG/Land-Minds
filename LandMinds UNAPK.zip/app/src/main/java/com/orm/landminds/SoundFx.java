    package com.orm.landminds;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

public class SoundFx {

    private static SoundPool soundPool;
    private static int hitSound, overSound, nextSound, plantSound;
    public SoundFx(Context context){

//        SoundPool (int maxStreams,int streamType,int srcQuality)
        soundPool = new SoundPool(2,AudioManager.STREAM_MUSIC,0);

        hitSound = soundPool.load(context,R.raw.explode1,1);
        overSound = soundPool.load(context,R.raw.primed,1);
        nextSound = soundPool.load(context,R.raw.leveldone,1);
        plantSound = soundPool.load(context,R.raw.plant,1);
    }
    public void playHitSound()  {

        soundPool.play(hitSound,1.0f,1.0f,1,0,1.0f);
    }
    public void playPrimedSound(){
        soundPool.play(overSound,1.0f,1.0f,1,0,1.0f);
    }
    public void playNextSound(){
        soundPool.play(nextSound,1.0f,1.0f,1,0,1.0f);
    }
    public void playplantSound(){
        soundPool.play(plantSound,1.0f,1.0f,1,0,1.0f);
    }
}
